package com.cs360.warehousewizard;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateItemActivity extends AppCompatActivity {
    //CREATE NEW ITEM SCREEN

    EditText itemName, itemQuantity;
    Button Create, Cancel;
    String currName, currQty;
    SQLiteDatabase db;
    SQLiteItemDB itemdb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_item);

        //edittext values used for new item creation
        itemName = findViewById(R.id.itemname);

        itemQuantity = findViewById(R.id.itemq);

        //create and cancel buttons
        Create = findViewById(R.id.additem);
        Cancel = findViewById(R.id.cancel);
        itemdb = new SQLiteItemDB(this);

        Create.setOnClickListener(this::onCreateClick);
        Cancel.setOnClickListener(this::onCancelClick);

    }

    private void onCreateClick(View view){
        currName = itemName.getText().toString();
        currQty = itemQuantity.getText().toString();

        db = itemdb.getWritableDatabase();

        Item item = new Item(currName, currQty);
        itemdb.addItem(item);
        Toast.makeText(CreateItemActivity.this,"Item Created!", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(CreateItemActivity.this, DatabaseActivity.class);
        startActivity(intent);
        this.finish();
    }

    private void onCancelClick(View view) {
        Intent intent = new Intent(CreateItemActivity.this, DatabaseActivity.class);
        startActivity(intent);
    }

}
