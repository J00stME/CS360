package com.cs360.warehousewizard;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    //Login screen

    Button Login, Register;
    EditText User, Pass;
    String currUser, currPass;
    String tempUser, tempPass;
    SQLiteDatabase db;
    SQLiteUserDB userdb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize objects to their XML counterparts
        Login = findViewById(R.id.login);
        Register = findViewById(R.id.newAcc);
        User = findViewById(R.id.user);
        Pass = findViewById(R.id.pass);
        userdb = new SQLiteUserDB(this);

        //set listeners for login and register
        Login.setOnClickListener(this::onLoginClick);
        Register.setOnClickListener(this::onRegisterClick);


    }

    //navigates to account creation activity
    private void onRegisterClick(View view) {
        Intent intent = new Intent(MainActivity.this, CreateAccActivity.class);
        startActivity(intent);
    }

    //attempts login
    public void onLoginClick(View view){
        //takes values of current EditTexts
        currUser = User.getText().toString();
        currPass = Pass.getText().toString();
        db = userdb.getWritableDatabase();

        //queries database for specified username
        String sql = "select * from users where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { currUser });

        //if username found, grabs password
        while (cursor.moveToNext()) {
            if(cursor.isFirst()){
                cursor.moveToFirst();
                tempPass = cursor.getString(2);
                cursor.close();
            }
        }

        userdb.close();

        checkCrudentials();

    }

    //checks if entered credentials are valid
    public void checkCrudentials(){
        //if pass from EditText equals that from DB, logs in
        if(currPass.equals(tempPass)){
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, DatabaseActivity.class);
            //intent.putExtras(bundle);
            startActivity(intent);
        }
        else{
            //if invalid, empties password field
            Pass.setText("");
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }
}