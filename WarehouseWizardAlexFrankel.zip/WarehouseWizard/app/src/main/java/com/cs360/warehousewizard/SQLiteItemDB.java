package com.cs360.warehousewizard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.*;


public class SQLiteItemDB extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "itemsFINAL.DB";
    private static final int VERSION = 1;

    public SQLiteItemDB(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemTable{
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item";
        private static final String COL_QUANTITY = "quantity";
    }

    //creates table
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + SQLiteItemDB.ItemTable.TABLE + " (" +
                SQLiteItemDB.ItemTable.COL_ID + " integer primary key autoincrement, " +
                SQLiteItemDB.ItemTable.COL_ITEM + " text, " +
                SQLiteItemDB.ItemTable.COL_QUANTITY + " text)");
    }

    //upgrades DB
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + SQLiteItemDB.ItemTable.TABLE);
        onCreate(db);
    }

    public void addItem(Item item){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_ITEM, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());

        db.insert(ItemTable.TABLE, null, values);
    }

    public void updateItem(Item item){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemTable.COL_ITEM, item.getName());
        values.put(ItemTable.COL_QUANTITY, item.getQuantity());

        db.update(ItemTable.TABLE, values, ItemTable.COL_ID + " = ?", new String[] { String.valueOf(item.getId()) });
    }

    public void removeItem(Item item){
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(ItemTable.TABLE, ItemTable.COL_ID + " = ?", new String[] { String.valueOf(item.getId()) });
    }

    public Item readItem(int id){
        Item item;
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + ItemTable.TABLE + " where _id = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { String.valueOf(id) });

        if(cursor != null)
            cursor.moveToFirst();

        item = new Item(cursor.getString(1),cursor.getString(2));
        cursor.close();
        return item;
    }

    public List<Item> gridDisplay(){
        List<Item> items = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + ItemTable.TABLE;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(Integer.parseInt(cursor.getString(0)));
                item.setName(cursor.getString(1));
                item.setQuantity(cursor.getString(2));
                items.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return items;
    }

    public int getNumItems() {
        String countQuery = "SELECT * FROM " + ItemTable.TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();

        return itemsTotal;
    }
}
