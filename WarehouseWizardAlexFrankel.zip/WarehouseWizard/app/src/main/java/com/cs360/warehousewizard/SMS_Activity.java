package com.cs360.warehousewizard;


import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SMS_Activity {

    public static AlertDialog smsRequest(final DatabaseActivity context){
        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.smsnotif)
                .setCancelable(false)
                .setMessage(R.string.smsmessage)
                .setPositiveButton(R.string.smsyes, (dialog, arg1) -> {
                    Toast.makeText(context, "Enable SMS", Toast.LENGTH_LONG).show();
                    DatabaseActivity.AllowSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.smsno, (dialog, arg1) -> {
                    Toast.makeText(context, "Disable SMS", Toast.LENGTH_LONG).show();
                    DatabaseActivity.DenySMS();
                    dialog.cancel();
                });

        // Create the AlertDialog object and return it
        return builder.create();
    }
}

