package com.cs360.warehousewizard;

public class User {
    //Stores values related to user
    int id;
    String userName;
    String userPass;

    public User(String u, String p){
        this.userName = u;
        this.userPass = p;
    }

    public void setUname(String u){
        this.userName = u;
    }

    public void setPass(String p){
        this.userPass = p;
    }

    public void setId(int id){
        this.id = id;
    }

    public int getId(){
        return this.id;
    }

    public String getUname(){
        return this.userName;
    }

    public String getPass(){
        return this.userPass;
    }
}
