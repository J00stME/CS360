package com.cs360.warehousewizard;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.sql.Array;
import java.util.ArrayList;

public class DatabaseActivity extends AppCompatActivity {

    private static boolean smsAllowed = false;

    public static void AllowSMS() {
        smsAllowed = true;
    }

    public static void DenySMS() {
        smsAllowed = false;
    }

    static ArrayList<Item> items;
    FloatingActionButton addition;
    ImageButton SMSButton;
    static SQLiteItemDB db;
    AlertDialog ad;
    static ListView itemview;
    static ListViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        addition = findViewById(R.id.addButton);

        SMSButton = findViewById(R.id.smsbutton);


        db = new SQLiteItemDB(this);

        items = (ArrayList<Item>) db.gridDisplay();

        itemview = findViewById(R.id.listview);

        adapter = new ListViewAdapter(this, items);
        itemview.setAdapter(adapter);

        int howmany = db.getNumItems();

        if(howmany == 0){
            Toast.makeText(this,"There are currently no items in the DataBase", Toast.LENGTH_LONG).show();
        }


        //floating action opens create new item activity
        addition.setOnClickListener(view ->{
            Intent additem = new Intent(DatabaseActivity.this, CreateItemActivity.class);
            startActivity(additem);
        });

        //SMS Button asks for permission
       SMSButton.setOnClickListener(view -> {
            // Requests SMS permission
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        android.Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {android.Manifest.permission.SEND_SMS},
                            0);
                }
            } else {
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            // Open SMS Alert Dialog
            ad = SMS_Activity.smsRequest(this);
            ad.show();
        });





        };

    //removes item from listview and DB
    public static void removeItem(int item){
        //uses position to dynamically remove but uses reference
        //from the current list to pass to the DB remove function
        db.removeItem(items.get(item));
        items.remove(item);
        itemview.setAdapter(adapter);
    }

    //EDITS item value in view and db
    public static void editItem(Item item, String s){
        item.setQuantity(s);
        db.updateItem(item);
        items = (ArrayList<Item>) db.gridDisplay();
        itemview.setAdapter(adapter);
    }

    public static void SendSMSMessage(Context context) {
        String phoneNumber = "5084983534"; //my phone number placeholder

        String smsMessage = "One of your items has reached a quantity of 0";

        // Evaluate AlertDialog permission to send SMS and ItemQtyValue value
        if (smsAllowed) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, smsMessage, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
        }
    }




}
