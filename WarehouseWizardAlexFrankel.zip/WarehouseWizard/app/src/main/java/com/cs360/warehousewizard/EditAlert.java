package com.cs360.warehousewizard;

import android.content.DialogInterface;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

//ALERT DIALOG WITH EDITTEXT ALLOWS CUSTOM QUANTITY CHANGE
public class EditAlert {
    public static AlertDialog editalert(final DatabaseActivity context, Item item) {
        // Use the Builder class for convenient dialog construction
        final EditText taskEditText = new EditText(context);
        AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle("Change the quantity")
                .setMessage("Enter a quantity:")
                .setView(taskEditText)
                .setPositiveButton("Change", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String edit = String.valueOf(taskEditText.getText());

                        //if updating value to 0, send SMS if enabled
                        if(edit == "0"){
                            DatabaseActivity.SendSMSMessage(context);
                        }

                        //calls to edit item with item reference and new String value edit
                        DatabaseActivity.editItem(item, edit);

                    }
                })
                .setNegativeButton("Cancel", null)
                .create();
        return dialog;
    }

}
