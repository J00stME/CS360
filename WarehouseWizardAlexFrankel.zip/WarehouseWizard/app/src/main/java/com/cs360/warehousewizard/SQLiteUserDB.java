package com.cs360.warehousewizard;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class SQLiteUserDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "logins.db";
    private static final int VERSION = 1;

    //creates database if first run
    public SQLiteUserDB(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    //class for table name and column names
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_UNAME = "username";
        private static final String COL_PWORD = "password";
    }

    //creates table
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_UNAME + " text, " +
                UserTable.COL_PWORD + " text)");
    }

    //upgrades DB
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        onCreate(db);
    }


    //currently only supports adding new users
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_UNAME, user.getUname());
        values.put(UserTable.COL_PWORD, user.getPass());

        db.insert(UserTable.TABLE, null, values);
        db.close();
    }


}
