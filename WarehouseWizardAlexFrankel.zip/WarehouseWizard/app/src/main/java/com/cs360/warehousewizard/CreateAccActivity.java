package com.cs360.warehousewizard;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateAccActivity extends AppCompatActivity {

    EditText User, Pass;

    String currUser, currPass;

    Button Create, Cancel;

    SQLiteDatabase db;

    SQLiteUserDB userdb;

    boolean userExists = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createacc);

        //user and pass edittexts, create and cancel buttons
        User = findViewById(R.id.user);
        Pass = findViewById(R.id.pass);
        Create = findViewById(R.id.create);
        Cancel = findViewById(R.id.cancel);
        //new instance of user database
        userdb = new SQLiteUserDB(this);

        //set listeners for buttons
        Create.setOnClickListener(this::onCreateClick);
        Cancel.setOnClickListener(this::onCancelClick);

    }

    //cancel will return to home screen
    private void onCancelClick(View view) {
        Intent intent = new Intent(CreateAccActivity.this, MainActivity.class);
        //intent.putExtras(bundle);
        startActivity(intent);
    }

    //creates new account on create button click
    private void onCreateClick(View view) {
        currUser = User.getText().toString();
        currPass = Pass.getText().toString();
        db = userdb.getWritableDatabase();

        userExists = false;

        String sql = "select * from users where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { currUser });

        while (cursor.moveToNext()) {
            if(cursor.isFirst()){
                cursor.moveToFirst();
                userExists = true;
                cursor.close();
            }
        }
        userdb.close();

        //only creates user if username doesn't exist yet
        if(userExists){
            User.setText("");
            Pass.setText("");
            Toast.makeText(this, "Username exists", Toast.LENGTH_SHORT).show();
        }
        else{
            createUser();
        }
    }

    //adds user to DB, returns to login screen
    private void createUser() {
        User user = new User(currUser, currPass);
        userdb.addUser(user);
        Toast.makeText(CreateAccActivity.this,"Account Created!", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(CreateAccActivity.this, MainActivity.class);
        //intent.putExtras(bundle);
        startActivity(intent);
        this.finish();
    }
}
