package com.cs360.warehousewizard;

public class Item {
    //item class represents an Item with unique name and quantity
    //MAY BE EXPANDED UPON IN FUTURE VERSIONS

    int id;
    String name;
    String quantity;


    public Item(){
        super();
    }

    public Item(String n, String q){
        this.name = n;
        this.quantity = q;
    }

    public void setId(int id){
        this.id = id;
    }

    public int getId(){
        return this.id;
    }

    public void setName(String n){
        this.name = n;
    }

    public String getName(){
        return this.name;
    }

    public void setQuantity(String q){
        this.quantity = q;
    }

    public String getQuantity(){
        return this.quantity;
    }

    @Override
    public String toString() {
        return "NAME:   " + name + "   QUANTITY:   " + quantity;
    }
}
