package com.cs360.warehousewizard;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;

public class ListViewAdapter extends ArrayAdapter<Item> {

    ArrayList<Item> list;
    Context context;
    String currEdit;

    public ListViewAdapter(Context context, ArrayList<Item> items){
        super(context, R.layout.custom_row, items);
        this.context= context;
        list = items;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView == null){
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(MainActivity.LAYOUT_INFLATER_SERVICE);

            //uses custom row design in listview
            convertView = layoutInflater.inflate(R.layout.custom_row, null);

            //database ID field
            TextView number = convertView.findViewById(R.id.number);
            number.setText(String.valueOf(list.get(position).getId()));

            //database name + quantity field
            TextView name = convertView.findViewById(R.id.name);
            name.setText(list.get(position).toString());

            //edit and delete buttons
            ImageView edit = convertView.findViewById(R.id.edit);
            ImageView delete = convertView.findViewById(R.id.delete);


            //on edit click summons ALERT that allows new edit value
            edit.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                    //alert dialog asks for new value
                    AlertDialog ad = EditAlert.editalert((DatabaseActivity) context, list.get(position));
                    ad.show();
                }
            });

            //calls delete function
            delete.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                    Toast.makeText(context, "Item Removed", Toast.LENGTH_LONG).show();
                    DatabaseActivity.removeItem(position);
                }
            });
        }
        return convertView;
    }
}
